﻿//Essam Fendish
//ICE 3: Calling forms on multiple files
//June 30, 2022
//
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ICE3
{
    public partial class frmIce3 : Form
    {
        public frmIce3()
        {
            InitializeComponent();
        }

        
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int Y = (Int32)numericUpDownY.Value;
            int X = (Int32)numericUpDownX.Value;
            frmCalculate frm = new frmCalculate(X,Y);
            frm.ShowDialog();
        }
    }
}
