﻿
namespace ICE3
{
    partial class frmCalculate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAddition = new System.Windows.Forms.Label();
            this.lblSubtraction = new System.Windows.Forms.Label();
            this.lblMultiplication = new System.Windows.Forms.Label();
            this.lblDivision = new System.Windows.Forms.Label();
            this.lblExponent = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblAddition
            // 
            this.lblAddition.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAddition.Location = new System.Drawing.Point(195, 94);
            this.lblAddition.Name = "lblAddition";
            this.lblAddition.Size = new System.Drawing.Size(122, 25);
            this.lblAddition.TabIndex = 0;
            // 
            // lblSubtraction
            // 
            this.lblSubtraction.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSubtraction.Location = new System.Drawing.Point(195, 139);
            this.lblSubtraction.Name = "lblSubtraction";
            this.lblSubtraction.Size = new System.Drawing.Size(122, 25);
            this.lblSubtraction.TabIndex = 1;
            // 
            // lblMultiplication
            // 
            this.lblMultiplication.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblMultiplication.Location = new System.Drawing.Point(195, 186);
            this.lblMultiplication.Name = "lblMultiplication";
            this.lblMultiplication.Size = new System.Drawing.Size(122, 25);
            this.lblMultiplication.TabIndex = 2;
            // 
            // lblDivision
            // 
            this.lblDivision.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDivision.Location = new System.Drawing.Point(195, 237);
            this.lblDivision.Name = "lblDivision";
            this.lblDivision.Size = new System.Drawing.Size(122, 25);
            this.lblDivision.TabIndex = 3;
            // 
            // lblExponent
            // 
            this.lblExponent.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblExponent.Location = new System.Drawing.Point(195, 290);
            this.lblExponent.Name = "lblExponent";
            this.lblExponent.Size = new System.Drawing.Size(122, 25);
            this.lblExponent.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "X + Y";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "X - Y";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 186);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "X * Y";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 237);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "X/Y";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 290);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "X ^ Y";
            // 
            // frmCalculate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 440);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblExponent);
            this.Controls.Add(this.lblDivision);
            this.Controls.Add(this.lblMultiplication);
            this.Controls.Add(this.lblSubtraction);
            this.Controls.Add(this.lblAddition);
            this.Name = "frmCalculate";
            this.Text = "frmCalculate";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAddition;
        private System.Windows.Forms.Label lblSubtraction;
        private System.Windows.Forms.Label lblMultiplication;
        private System.Windows.Forms.Label lblDivision;
        private System.Windows.Forms.Label lblExponent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}