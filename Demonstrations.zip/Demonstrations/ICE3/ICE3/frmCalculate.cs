﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ICE3
{
    public partial class frmCalculate : Form
    {
        public frmCalculate()
        {
            InitializeComponent();
        }

        public frmCalculate(int X, int Y)
        {
            InitializeComponent();

            lblAddition.Text = (X + Y).ToString();
            lblSubtraction.Text = (X - Y).ToString();
            lblMultiplication.Text = (X * Y).ToString();
           if(!(Y==0)) lblDivision.Text = (X / Y).ToString();
            lblExponent.Text = Math.Pow(X, Y).ToString();
          
            

        }
    }
}
