﻿
namespace Lab3_New_
{
    partial class frmMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAddNew = new System.Windows.Forms.Button();
            this.dgvCharacters = new System.Windows.Forms.DataGridView();
            this.colCharacterID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFirstName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLastName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colClass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRace = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colWeapon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLevel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCharacters)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAddNew
            // 
            this.btnAddNew.Location = new System.Drawing.Point(754, 615);
            this.btnAddNew.Name = "btnAddNew";
            this.btnAddNew.Size = new System.Drawing.Size(168, 79);
            this.btnAddNew.TabIndex = 1;
            this.btnAddNew.Text = "&Add New";
            this.btnAddNew.UseVisualStyleBackColor = true;
            this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
            // 
            // dgvCharacters
            // 
            this.dgvCharacters.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCharacters.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCharacterID,
            this.colFirstName,
            this.colLastName,
            this.colClass,
            this.colRace,
            this.colWeapon,
            this.colLevel});
            this.dgvCharacters.Location = new System.Drawing.Point(12, 12);
            this.dgvCharacters.Name = "dgvCharacters";
            this.dgvCharacters.RowHeadersWidth = 51;
            this.dgvCharacters.RowTemplate.Height = 29;
            this.dgvCharacters.Size = new System.Drawing.Size(1013, 188);
            this.dgvCharacters.TabIndex = 2;
            this.dgvCharacters.SelectionChanged += new System.EventHandler(this.Selection_Changed);
            // 
            // colCharacterID
            // 
            this.colCharacterID.DataPropertyName = "characterID";
            this.colCharacterID.HeaderText = "ID";
            this.colCharacterID.MinimumWidth = 6;
            this.colCharacterID.Name = "colCharacterID";
            this.colCharacterID.Width = 125;
            // 
            // colFirstName
            // 
            this.colFirstName.DataPropertyName = "FirstName";
            this.colFirstName.HeaderText = "First Name";
            this.colFirstName.MinimumWidth = 6;
            this.colFirstName.Name = "colFirstName";
            this.colFirstName.Width = 125;
            // 
            // colLastName
            // 
            this.colLastName.DataPropertyName = "LastName";
            this.colLastName.HeaderText = "Last Name";
            this.colLastName.MinimumWidth = 6;
            this.colLastName.Name = "colLastName";
            this.colLastName.Width = 125;
            // 
            // colClass
            // 
            this.colClass.DataPropertyName = "Class";
            this.colClass.HeaderText = "Class";
            this.colClass.MinimumWidth = 6;
            this.colClass.Name = "colClass";
            this.colClass.Width = 125;
            // 
            // colRace
            // 
            this.colRace.DataPropertyName = "Race";
            this.colRace.HeaderText = "Race";
            this.colRace.MinimumWidth = 6;
            this.colRace.Name = "colRace";
            this.colRace.Width = 125;
            // 
            // colWeapon
            // 
            this.colWeapon.DataPropertyName = "Weapon";
            this.colWeapon.HeaderText = "Weapon";
            this.colWeapon.MinimumWidth = 6;
            this.colWeapon.Name = "colWeapon";
            this.colWeapon.Width = 125;
            // 
            // colLevel
            // 
            this.colLevel.DataPropertyName = "Level";
            this.colLevel.HeaderText = "Level";
            this.colLevel.MinimumWidth = 6;
            this.colLevel.Name = "colLevel";
            this.colLevel.Width = 125;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1037, 734);
            this.Controls.Add(this.dgvCharacters);
            this.Controls.Add(this.btnAddNew);
            this.Name = "frmMain";
            this.Text = "Lab 3";
            this.Activated += new System.EventHandler(this.HeyResetMe);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCharacters)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnAddNew;
        private System.Windows.Forms.DataGridViewTextBoxColumn Weapons;
        private System.Windows.Forms.DataGridView dgvCharacters;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCharacterID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFirstName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLastName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colClass;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRace;
        private System.Windows.Forms.DataGridViewTextBoxColumn colWeapon;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLevel;
    }
}

