﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3New
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        #region GLOBAL VARIABLES
        int CharacterID = 0;
        Boolean DoSelectionChange = false;

        #endregion
        #region CUSTOM METHODS



        private void UpdateDataGrid()
        {
            DoSelectionChange = false;
            dgvCharacters.DataSource = null;
            dgvCharacters.DataSource = Characters.characters;
            dgvCharacters.ClearSelection();
            DoSelectionChange = true;
        }

        public void HeyResetMe(object sender, EventArgs e)
        {
            UpdateDataGrid();
        }
        private void Selection_Changed(object sender, EventArgs e)
        {
            if (DoSelectionChange && dgvCharacters.SelectedRows.Count > 0)
            {

                int chrID = int.Parse(dgvCharacters.SelectedRows[2].Cells[2].Value.ToString());
                Editor frmNew = new Editor(chrID);
                frmNew.Show();


            }

        }
        #endregion

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            Editor frmNew = new Editor();
            frmNew.Show();
        }


    }
}