﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Editor : Form
    {
        public Editor()
        {
            InitializeComponent();
        }

        public Editor(int characterID)
        {
            InitializeComponent();
            Characters chr = FindCharacter(characterID);
            this.chr = chr;
            
        }

        Characters chr = null;
        List<String> Classes = new List<String>();
        List<String> Races = new List<String>();
        List<String> Weaponss = new List<String>();
        private void SetDefault()
        {

            nudLevel.Value = 0;
            txtFirstName.Clear();
            txtLastName.Clear();
            cboClass.SelectedIndex = -1;
            cboRace.SelectedIndex = -1;
            cboWeapon.SelectedIndex = -1;

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            SetDefault();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            
            Characters chr = new Characters();
            if (this.chr != null)
            {
                chr = this.chr;
            }
            chr.FirstName = txtFirstName.Text;
            chr.LastName = txtLastName.Text;
            chr.Race = cboRace.Text;
            chr.Class = cboClass.Text;
            chr.Weapon = cboWeapon.Text;
            chr.Level = Convert.ToInt32(nudLevel.Value);

            if (this.chr == null)
            {
                Characters.characters.Add(chr);
            }

            

            
               
            
            this.Close();
        }
        private void PopulateCharacter(Characters chr)
        {
            nudID.Value = chr.characterID;
            txtFirstName.Text = chr.FirstName;
            txtLastName.Text = chr.LastName;
            cboClass.Text = chr.Class;
            cboRace.Text = chr.Race;
            cboWeapon.Text = chr.Weapon;
            nudLevel.Value = chr.Level;
        }
        private void PopulateClass()
        {
            Classes.Add("Barbarian");
            Classes.Add("Bard");
            Classes.Add("Cleric");
            Classes.Add("Druid");
            Classes.Add("Fighter");
            Classes.Add("Monk");
            Classes.Add("Paladin");
            Classes.Add("Ranger");
            Classes.Add("Rogue");
            Classes.Add("Sorcerer");
            Classes.Add("Warlock");
            Classes.Add("Wizard");
        }

        private void PopulateRaces()
        {
            Races.Add("Dragonborn");
            Races.Add("Dwarf");
            Races.Add("Elf");
            Races.Add("Gnome");
            Races.Add("Half-Elf");
            Races.Add("Halfling");
            Races.Add("Half-Orc");
            Races.Add("Human");
            Races.Add("Tiefling");
        }

        private void PopulateWeapons()
        {
            Weaponss.Add("Greatsword");
            Weaponss.Add("Battleaxe");
            Weaponss.Add("Longsword");
            Weaponss.Add("Scimitar");
            Weaponss.Add("Warhammer");
            Weaponss.Add("Longbow");
            Weaponss.Add("Arcane Staff");
            Weaponss.Add("Trident");
            Weaponss.Add("Morningstar");
        }
        public static Characters FindCharacter(int characterID)
        {
            return Characters.characters.Find(t => t.characterID == characterID);


        }

        private void Editor_Load(object sender, EventArgs e)
        {
            PopulateClass();
            PopulateRaces();
            PopulateWeapons();
            cboClass.DataSource = Classes;
            cboRace.DataSource = Races;
            cboWeapon.DataSource = Weaponss;

            if (chr == null)
            {
                SetDefault();
            }
            else
            {
                PopulateCharacter(chr);
            }
            

        }
    } 

}
