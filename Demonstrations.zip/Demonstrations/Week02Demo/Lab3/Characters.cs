﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    public class Characters
    {
        #region GLOBAL VARIABLES

        public static List<Characters> characters = new List<Characters>();
        private static int nextID = 1; 
        #endregion

        #region PROPERTIES
        public int characterID { get; set; }
        public int Level { get; set; }
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public String Race { get; set; }
        public String Class { get; set; }
        public String Weapon { get; set; }

        #endregion
        #region CONSTRUCTORS

        public Characters()
        {
            characterID = nextID++;

            SetDefaults();


        }

        public Characters(String firstName, String lastName, String race, String CLass, String weapon)
        {
            FirstName = firstName;
            LastName = lastName;
            Race = race;
            Class = CLass;
            Weapon = weapon;
        }


        #endregion
        #region METHODS

        private void SetDefaults()
        {
            Level = 0;
            FirstName = string.Empty;
            LastName = string.Empty;
            Race = string.Empty;
            Class = string.Empty;
            Weapon = string.Empty;
        }

        
        #endregion

    }
}
